# Yimms — Shopify theme scaffold

This repository contains a minimal Shopify theme scaffold generated to serve as a starting point.

How to use

- Clone the repo
- Open the folder in Shopify CLI or upload the theme files to your store

If you want me to push the changes to GitHub from this machine, provide a way to authenticate (SSH key or PAT configured), or push locally and I'll guide you.
